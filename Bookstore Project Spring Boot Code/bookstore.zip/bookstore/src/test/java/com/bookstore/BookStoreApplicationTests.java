package com.bookstore;

import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.test.context.support.WithMockUser;
import com.bookstore.controller.HomeController;

@WebMvcTest(value = HomeController.class)
@WithMockUser
@SpringBootTest
class BookStoreApplicationTests {
//    @Autowired
//    MockMvc mockMvc;
//    @Autowired
//    ObjectMapper mapper;
//	@Autowired
//	private MockMvc mockMvc;
//    @MockBean
//    private ProductService productService;

	
//    @Test
//	public void retrieveDetailsForCourse() throws Exception {
//
//		Mockito.when(
//				productService.showProductById(Mockito.anyInt())).thenReturn(null);
//
//		RequestBuilder requestBuilder = MockMvcRequestBuilders.get(
//				"/home/product/89").accept(
//				MediaType.APPLICATION_JSON);
//
//		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
//		System.out.println(result.getResponse());
//		String expected = "{id:Course1,name:Spring,description:10Steps}";
//
//		// {"id":"Course1","name":"Spring","description":"10 Steps, 25 Examples and 10K Students","steps":["Learn Maven","Import Project","First Example","Second Example"]}
//
//		JSONAssert.assertEquals(expected, result.getResponse()
//				.getContentAsString(), false);
//	}
}
