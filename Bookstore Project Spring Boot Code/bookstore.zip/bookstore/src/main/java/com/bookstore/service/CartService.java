package com.bookstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.bookstore.exception.CustomeException;
import com.bookstore.model.Cart;
import com.bookstore.model.Product;
import com.bookstore.payload.request.CartRequest;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.repository.CartRepo;
import com.bookstore.repository.ProductRepo;

@Service
public class CartService {
	@Autowired
	private CartRepo cartRepo;
	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private	SequenceGeneratorService sequenceGeneratorService;



	public ResponseEntity<?> showCart(String emailId) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			BaseResponse<List<Cart>> response = new BaseResponse<>();
			List<Cart>	list=cartRepo.findAllCartByEmailId(emailId);
			if (list.size()>0) {
				response.setStatus(200);
				response.setData(list);
				tr= ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				response.setStatus(400);
				response.setMessage("No Products in Cart");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}			
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  showCart", e);
		}
		return tr ;	
	}

	public ResponseEntity<?> addCart(CartRequest cartRequest, String emailId) throws CustomeException  {
		ResponseEntity<?> tr=null;
		try {
			Product product = productRepo.findProductsById(cartRequest.getId());	
			BaseResponse<String> response = new BaseResponse<>();
			if(product!=null)
			{
				if(cartRequest.getQuantity()>=1) {
					Cart cart = new Cart();
					cart.setEmailId(emailId);
					cart.setProduct(product);
					cart.setId((int) sequenceGeneratorService.generateSequence(Cart.SEQUENCE_NAME));
					cart.setQuantity(cartRequest.getQuantity());
					Double totalPrice = (double) (cartRequest.getQuantity() * product.getPrice());
					cart.setTotalPrice(totalPrice);
					cartRepo.save(cart);
					response.setStatus(200);
					response.setMessage(cartRequest.getId() + " Successfull added to cart");
					tr = ResponseEntity.ok().body(response);

				} else {
					response.setStatus(400);
					response.setMessage(" Quantity must be 1 or more");
					tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);	
				}
			}
			else {
				response.setStatus(400);
				response.setMessage(cartRequest.getId() +" Product Not Found");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  addCart", e);
		}
		return tr ;	
	}

	public BaseResponse<String> deleteCart(int id) // throws CustomeException 
	{
		try {
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setMessage("Successfully Deleted");
			cartRepo.deleteById(id);
			return response;
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  deleteCart", e);
		}

	}

	public BaseResponse<String> deleteAllCart(String emailId) throws CustomeException {
		try {
			cartRepo.deleteAllCartItemsByEmailId(emailId);
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setMessage("Successfully All Items Deleted");
			return response ;
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  deleteAllCart", e);
		}
	}

	public ResponseEntity<?> updateCart(CartRequest cartRequest)  throws CustomeException {
		ResponseEntity<?>  tr=null;
		try {
			Cart cart=cartRepo.findCartById(cartRequest.getId());
			BaseResponse<String> response = new BaseResponse<>();	
			if(cart!=null )
			{
				if(cartRequest.getQuantity()>=1) {
					Cart cart2 = new Cart();
					cart2.setId(cart.getId());
					cart2.setEmailId(cart.getEmailId());
					cart2.setProduct(cart.getProduct());
					Double totalPrice = (double) (cartRequest.getQuantity() *cart.getProduct().getPrice()); 
					cart2.setTotalPrice(totalPrice);
					cart2.setQuantity(cartRequest.getQuantity());
					cartRepo.save(cart2);
					response.setStatus(200);
					response.setMessage("Successfully Updated");
					tr= ResponseEntity.ok().body(response);
				}
				else {	
					response.setStatus(400);
					response.setMessage(" Quantity must be 1 or more");
					tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}		
			}	
			else {
				response.setStatus(400);
				response.setMessage(cartRequest.getId() +" Product Not Found");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  updateCart", e);
		}
		return tr;
	}
}
