package com.bookstore.controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.exception.CustomeException;
import com.bookstore.payload.request.LoginRequest;
import com.bookstore.payload.request.SignupRequest;
import com.bookstore.payload.response.MessageResponse;
import com.bookstore.service.ProductService;
import com.bookstore.service.SigninSignupService;

@RestController
@RequestMapping("/home")
public class HomeController {
	private static Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Autowired
	private ProductService productService;

	@Autowired
	private SigninSignupService signinSignupService;

	// ------------------- Product Section
	// -----------------------------------------------------
	@GetMapping("/product")
	public ResponseEntity<?> getProducts(@RequestParam(value = "id", required = false, defaultValue = "0") Integer id,
			@RequestParam(value = "category", required = false, defaultValue = "") String category,
			@RequestParam(value = "minRange", required = false, defaultValue = "0") Integer minRange,
			@RequestParam(value = "maxRange", required = false, defaultValue = "0") Integer maxRange,
			@RequestParam(value = "productName", required = false, defaultValue = "") String productName,
			@RequestParam(value = "sortType", required = false, defaultValue = "0") Integer sortType) {

		ResponseEntity<?> tr = null;
		try {
			tr = productService.getProduct(id, category, minRange, maxRange, productName, sortType);
		} catch (CustomeException e) {
			logger.error("Exception occurred in ProductService getAllProducts", e);
			tr = ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Invalid Number");
		}
		return tr;
	}
	// ------------------- End Home and Product Section---------------------------------------------------------

	// --------------------------------SignIn and SignUp Section--------------------------------------------------
	// 5. SignIn()

	@PostMapping("/signin")
	public ResponseEntity<?> authenticateUser(@Valid @RequestBody LoginRequest loginRequest,
			HttpServletRequest request) {
		ResponseEntity<?> tr = null;
		try {
			tr = signinSignupService.signIn(loginRequest, request);
		} catch (CustomeException e) {
			logger.error("Exception occurred in  signinSignupService SignUp", e);
		}
		if (tr != null) {
			return tr;
		} else {
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(new MessageResponse("User Not Found!"));
		}
	}

	// 6. SignUp()
	@PostMapping("/signup")
	public ResponseEntity<?> registerUser(@Valid @RequestBody SignupRequest signUpRequest) {
		ResponseEntity<?> tr = null;
		try {
			tr = signinSignupService.signUp(signUpRequest);
		} catch (CustomeException e) {
			logger.error("Exception occurred in  signinSignupService SignUp", e);

		}
		return tr;
	}

	// 7. ForgetPassword()
	// ---------------------------- End Login and SignUp Section--------------------------------------------------

}
