package com.bookstore.repository;

import java.util.List;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.bookstore.model.Checkout;
import com.bookstore.model.Order;

public interface OrderRepo extends MongoRepository<Order, Integer> {

	Order save(Checkout checkout);

	List<Order> findAllByEmailId(String emailId);

	void deleteAllByEmailId(String emailId);

}
