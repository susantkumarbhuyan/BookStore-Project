package com.bookstore.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.bookstore.model.Cart;

public interface CartRepo extends MongoRepository<Cart, Integer>{
	@Aggregation(pipeline = {
			"{'$match':{'emailId':?0}}",
			"{$group: { _id: null , totalCartPrice : {$sum: $totalPrice}}}"
		})
		public Double sumPrices(String emailId);

	public List<Cart> findAllCartByEmailId(String emailId);

	public void deleteAllCartItemsByEmailId(String emailId);

	public List<Cart> findAllCheckoutByEmailId(String emailId);

	 Cart findCartById(int id);



}
