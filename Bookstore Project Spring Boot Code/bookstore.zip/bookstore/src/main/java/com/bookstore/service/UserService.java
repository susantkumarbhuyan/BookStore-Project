package com.bookstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.bookstore.exception.CustomeException;
import com.bookstore.model.User;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.repository.UserRepo;

@Service
public class UserService {
	@Autowired
	private	UserRepo userRepo;


	public ResponseEntity<?> viewUser() throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			List<User> list= userRepo.findAll();
			BaseResponse<List<User>> response = new BaseResponse<>();
			if(list.size()>0) {
				response.setStatus(200);
				response.setData(list);
				tr= ResponseEntity.ok().body(response);
			}
			else {
				response.setStatus(204);
				response.setMessage("No Users");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		}catch(Exception e){
			throw new CustomeException("Exception occurred  in CartService  findAll", e);
		}
		return tr;
	}
	public ResponseEntity<BaseResponse<String>> deleteUserByUsername(String username) throws CustomeException {
		ResponseEntity<BaseResponse<String>> tr=null;
		try {
			User user =userRepo.findByUsername(username);
			BaseResponse<String> response = new BaseResponse<>();
			if(user!=null){ 	
				userRepo.deleteById(username);
				String name = user.getFullName();
				response.setStatus(200);
				response.setData(name +" User Successfully Deleted");
				tr=	ResponseEntity.status(HttpStatus.OK).body(response);
			}
			else {
				response.setStatus(400);
				response.setMessage( username+ " User Not found");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred  in CartService  deleteUserById", e);
		}
		return tr;
	}
	
	public ResponseEntity<BaseResponse<User>> viewUserByUsername(String username) throws CustomeException {
		ResponseEntity<BaseResponse<User>> tr=null;
		try {
			BaseResponse<User> response = new BaseResponse<>();
			User user =	userRepo.findByUsername(username);
			if(user!=null)
			{
				response.setStatus(200);
				response.setData(user);
				tr= ResponseEntity.status(HttpStatus.OK).body(response);
			}
			else {
				response.setStatus(400);
				response.setMessage(username+ " User Not found");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body( response);
			}

		} catch (Exception e) {
			throw new CustomeException("Exception occurred in UserService viewUserById", e);
		}	
		return tr;
	}

	public ResponseEntity<?> deleteAllUser() throws CustomeException {
		ResponseEntity<?> tr= null;
		try {
			userRepo.deleteAll();
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setData("All Users Deleted");
			tr=ResponseEntity.status(HttpStatus.OK).body(response);
		} catch (Exception e) {
			throw new CustomeException("Exception occurred in UserService deleteAllUser", e);
		}
		return tr;
	}

	public ResponseEntity<?> userviewUserDetails(String emailId) throws CustomeException {
		ResponseEntity<?> tr= null;
		try {
			BaseResponse<User> response = new BaseResponse<>();
			response.setStatus(200);
			response.setData( userRepo.findByEmailId(emailId));
			tr=ResponseEntity.status(HttpStatus.OK).body(response);
		}catch(Exception e){
			throw new CustomeException("Exception occurred in OrderService userviewUserDetails", e);
		}
		return tr;
	}
	public ResponseEntity<?> updateUserDetail( User user , String emailId) throws CustomeException {   // user can update only Email, Fullname, Username
		ResponseEntity<?> tr= null;
		try {		
			User ud=userRepo.findByEmailId(emailId);
			ud.setId(ud.getId());
			ud.setEmailId(ud.getEmail());
			ud.setRoles(ud.getRoles());
			ud.setEmail(user.getEmail());
			ud.setFullName(user.getFullName());
			ud.setUsername(user.getUsername());
			userRepo.save(ud);
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setMessage("Updated Your Details");
			tr=ResponseEntity.status(HttpStatus.OK).body(response);
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred in OrderService updateUserDetail", e);
		}
		return tr;
	}
}
