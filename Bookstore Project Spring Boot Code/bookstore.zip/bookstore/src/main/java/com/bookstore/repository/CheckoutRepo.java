package com.bookstore.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.Aggregation;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.bookstore.model.Address;
import com.bookstore.model.Checkout;
import com.bookstore.payload.request.CheckoutRequest;


public interface CheckoutRepo extends MongoRepository<Checkout, Integer>{

	Checkout save(Address address);


	@Aggregation(pipeline  ={
			"{'$match':{'emailId':?0}}"
	})
	CheckoutRequest findTotalCartPrice(String emailId);

	void deleteAllCheckoutByEmailId(String emailId);


	List<Checkout> findCheckoutByEmailId(String emailId);

}
