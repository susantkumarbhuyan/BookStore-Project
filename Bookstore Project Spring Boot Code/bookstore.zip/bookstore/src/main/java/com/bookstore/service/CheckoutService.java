package com.bookstore.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.bookstore.exception.CustomeException;
import com.bookstore.model.Address;
import com.bookstore.model.Cart;
import com.bookstore.model.Checkout;
import com.bookstore.model.Order;
import com.bookstore.model.User;
import com.bookstore.payload.request.CheckoutPaymentRequest;
import com.bookstore.payload.request.CheckoutRequest;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.pojo.CurrertDate;
import com.bookstore.repository.CartRepo;
import com.bookstore.repository.CheckoutRepo;
import com.bookstore.repository.OrderRepo;
import com.bookstore.repository.UserRepo;

@Service
public class CheckoutService {
	@Autowired
	private CheckoutRepo checkoutRepo;
	@Autowired
	private OrderRepo orderRepo;
	@Autowired
	private	CartRepo cartRepo;
	@Autowired
	private	SequenceGeneratorService sequenceGeneratorService;
	@Autowired
	private UserRepo userRepository;


	public ResponseEntity<?> addCheckout(Address address, String emailId) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			BaseResponse<Checkout> response = new BaseResponse<>();	
			List<Cart> cart= cartRepo.findAllCheckoutByEmailId(emailId);
			if(cart.size()>0) {
				Checkout checkout= new Checkout();
				checkout.setAddress(address);
				checkout.setEmailId(emailId);
				checkout.setId(emailId);
				checkout.setCart(cart);		
				Double totalCartPrice= cartRepo.sumPrices(emailId);
				checkout.setTotalCartPrice(totalCartPrice);
				response.setStatus(200);
				response.setData( checkoutRepo.save(checkout));
				tr= ResponseEntity.ok().body(response);			
			}
			else {
				response.setStatus(400);
				response.setMessage("No Products In Cart");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}

		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CheckoutService AddCheckOut", e);
		}
		return tr;
	}

	public ResponseEntity<?> orderCompleted( CheckoutPaymentRequest request, String emailId ) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			User user = userRepository.findByEmailId(emailId);
			CheckoutRequest ct= checkoutRepo.findTotalCartPrice(emailId);
			BaseResponse<String> response = new BaseResponse<>();
			if(request.getAmount()==ct.getTotalCartPrice()) {
				Order order= new Order();
				order.setOrderDate(new CurrertDate().getDateAndTime());      //Set Current Order Date
				order.setName(user.getFullName());
				order.setEmailId(user.getEmail());
				order.setAmount(request.getAmount());
				order.setPaymentWay(request.getPaymentWay());	
				order.setId((int) sequenceGeneratorService.generateSequence(Order.SEQUENCE_NAME));
				List<Checkout> ch= checkoutRepo.findCheckoutByEmailId(emailId);
				order.setProducts(ch);
				orderRepo.save(order);
				cartRepo.deleteAllCartItemsByEmailId(emailId);       //delete Cart items
				checkoutRepo.deleteAllCheckoutByEmailId(emailId);   //delete checkout items			
				response.setStatus(200);
				response.setMessage( "Successfully ordered");
				tr= ResponseEntity.ok().body(response);
			}
			else {
				response.setStatus(400);
				response.setMessage("Payment Failed");
				tr= ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);	
			}			
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CheckoutService OrderCompleted", e);
		}
		return tr;
	}

	public ResponseEntity<?> deleteAllCheckout(String emailId) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			checkoutRepo.deleteAllCheckoutByEmailId(emailId);
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setMessage("Checkout Deleted");
			tr= ResponseEntity.ok().body(response);
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CheckoutService  DeleteAllCheckout", e);
		}
		return tr;
	}

	public ResponseEntity<?> showCheckout() throws CustomeException
	{	
		ResponseEntity<?> tr=null;
		try {
			BaseResponse<List<Checkout>> response = new BaseResponse<>();
			List<Checkout> list =checkoutRepo.findAll();
			if (list.size()>0) {
				response.setStatus(200);
				response.setData(list);
				tr= ResponseEntity.ok().body(response);
			} else {
				response.setStatus(400);
				response.setMessage("No Products in Checkout");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred  in CheckoutService  ShowCheckout", e);
		}
		return tr;
	}



}
