package com.bookstore.payload.request;

import lombok.Data;

@Data
public class CheckoutPaymentRequest {
private Double amount;
private String paymentWay;
}
