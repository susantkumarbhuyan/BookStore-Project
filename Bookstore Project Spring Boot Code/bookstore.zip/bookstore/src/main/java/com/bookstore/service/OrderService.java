package com.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.bookstore.exception.CustomeException;
import com.bookstore.model.Order;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.repository.OrderRepo;


@Service
public class OrderService {
	@Autowired
	private OrderRepo orderRepo;


	public ResponseEntity<?> getAllOrders(String emailId) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			System.out.println("Order Service "+emailId);
			List<Order> list= orderRepo.findAllByEmailId(emailId);     
			BaseResponse<List<Order>> response = new BaseResponse<>();
			if(list.size()>0) {
				response.setStatus(200);
				response.setData(list);
				tr= ResponseEntity.ok().body(response);
			}
			else {
				response.setStatus(204);
				response.setMessage(" No Orders");
				tr=  ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}	
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred in OrderService getAllOrders", e);
		}
		return tr;    
	}

	public ResponseEntity<BaseResponse<String>> deleteOrderById(int id) throws CustomeException {
		ResponseEntity<BaseResponse<String>> tr=null; 
		try {
			BaseResponse<String> response = new BaseResponse<>();
			if(orderRepo.existsById(id)) {
				orderRepo.deleteById(id);
				response.setStatus(200);
				response.setData(id +" Order Successfully  Deleted");
				tr =	ResponseEntity.status(HttpStatus.OK).body(response); 
			}
			else {
				response.setStatus(400);
				response.setMessage(id+" Order id Doesn't Exist  Enter Valid Order Id");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred in OrderService deleteOrderById", e);
		}
return tr;
	}

	public ResponseEntity<?> deleteAllOrderByEmailId(String emailId) throws CustomeException {
		ResponseEntity<?> tr=null; 
		try {
			orderRepo.deleteAllByEmailId(emailId); 
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setData("All Orders Deleted");
			tr= ResponseEntity.ok(response) ;
		}
		catch(Exception e){
			throw new CustomeException("Exception occurred in OrderService deleteAllOrderByUui", e);
		}
		return tr;
	}

	public ResponseEntity<?> getAllOrder() throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			List<Order> list=	orderRepo.findAll();
			BaseResponse<List<Order>> response = new BaseResponse<>();
			if(list.size()>0) {
				response.setStatus(200);
				response.setData(list);
				tr= ResponseEntity.ok().body(response);
			}
			else {
				response.setStatus(204);
				response.setMessage("NO Orders!");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred in OrderService getAllOrder", e);
		}
		return tr;
	}

	public ResponseEntity<?> deleteAllOrder() throws CustomeException {
		ResponseEntity<?> tr = null;
		try {
			orderRepo.deleteAll();
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setData( "No Content All Orders Deleted By Admin");
			tr =ResponseEntity.status(HttpStatus.OK).body(response) ;	
		} catch (Exception e) {
			throw new CustomeException("Exception occurred in OrderService deleteAllOrder", e);
		}
		return tr;
	}
}
