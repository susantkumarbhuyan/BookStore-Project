package com.bookstore.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.bookstore.model.User;

public interface UserRepo extends MongoRepository<User, String> {

	User findByUsername(String username);

	Boolean existsByUsername(String username);
	Boolean existsByEmail(String email);

	User findByEmailId(String emailId);


}
