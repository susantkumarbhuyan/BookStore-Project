package com.bookstore.payload.request;

import lombok.Data;

@Data
public class CartRequest {
private int id;
private int quantity;	
}
