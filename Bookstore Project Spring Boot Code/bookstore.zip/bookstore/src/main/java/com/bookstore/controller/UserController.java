package com.bookstore.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.exception.CustomeException;
import com.bookstore.model.User;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.service.OrderService;
import com.bookstore.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	private static Logger logger = LoggerFactory.getLogger(UserController.class);
	@Autowired
	private	UserService userService;

	@Autowired
	private	OrderService orderService;


	//	1.	ShowAllOrders
	@GetMapping("/dashbord/orders")         
	public ResponseEntity<?> showAllOrder(HttpSession session)     
	{ ResponseEntity<?> tr=null;
	try {
		String emailId=	(String) session.getAttribute("emailId");
		tr= orderService.getAllOrders(emailId); 
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService getAllOrders", e);
	}
	return tr;
	}

	//	2.	Delete single 
	@DeleteMapping("/dashbord/orders/delete/{id}")
	public ResponseEntity<BaseResponse<String>> deleteOrdersById(@PathVariable("id") int id)
	{ ResponseEntity<BaseResponse<String>> tr = null;
	try {
		tr=	orderService.deleteOrderById(id);
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService deleteOrderById", e);
	}
	return tr;
	}

	// 2.1 Delete All Orders
	@DeleteMapping("/dashbord/orders/delete/all")
	public ResponseEntity<?> deleteAllOrders(HttpSession session) 
	{ ResponseEntity<?> tr=null; 
	try {
		String emailId=	(String) session.getAttribute("emailId");
		tr=	orderService.deleteAllOrderByEmailId(emailId);
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService deleteAllOrderByUui", e);
	}
	return tr;
	}

	//	3.	ShowUserDetails
	@GetMapping("/dashboard/details")

	public ResponseEntity<?> viewUserDetails(HttpSession session) throws Exception
	{ ResponseEntity<?> tr=null;
	try {
		String emailId=	(String) session.getAttribute("emailId");
		 tr=userService.userviewUserDetails(emailId);
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService userviewUserDetails", e);
	}
	return tr;
	}

	//	4.	Edit UserDetails
	@PutMapping("/dashboard/details/update")
	public ResponseEntity<?> updateUserDetails(@RequestBody User user, HttpSession session)
	{ ResponseEntity<?> tr = null;
	try {
		String emailId=	(String) session.getAttribute("emailId");
	tr=	userService.updateUserDetail(user , emailId);
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService updateUserDetail", e);
	}
	return tr;
	}


}
