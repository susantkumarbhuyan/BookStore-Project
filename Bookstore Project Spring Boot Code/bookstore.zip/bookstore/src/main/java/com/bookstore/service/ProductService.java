package com.bookstore.service;

import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.bookstore.exception.CustomeException;
import com.bookstore.model.Product;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.repository.ProductRepo;

@Service
public class ProductService {

	@Autowired
	private ProductRepo productRepo;
	@Autowired
	private SequenceGeneratorService sequenceGeneratorService;



	public ResponseEntity<?> getProduct(int id, String category, int minRange, int maxRange, String productName,
			int sortType) throws CustomeException {
		ResponseEntity<?> tr = null;
		BaseResponse<List<Product>> response = new BaseResponse<>();
		try {
			// View Single Product By Id
			if (id != 0) {
				List<Product> list = productRepo.findProductById(id);;
				if (list.size() > 0) {
					response.setStatus(200);
					response.setData(list);
					tr = ResponseEntity.ok().body(response);
				} else {
					response.setStatus(400);
					response.setMessage(id + " Product ID Does not exist");
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			}
			// Show product By Category
			else if (category != null && !category.isEmpty()) {
				List<Product> list = productRepo.findProductByCategory(category);
				if (list.size() > 0) {
					response.setStatus(200);
					response.setData(list);
					tr = ResponseEntity.ok(response);
				} else {
					response.setStatus(400);
					response.setMessage(category + " Category  does not exist");
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			}
			// Filter Product by Price Minimum and maximum
			else if (minRange != 0 && maxRange != 0) {
				List<Product> list = productRepo.filterByPrice(minRange, maxRange);;
				if (list.size() > 0) {					
					response.setStatus(200);					
					response.setData(list);					
					tr = ResponseEntity.ok(response);					
				} else {					
					response.setStatus(400);	
					response.setMessage("No Products between " + minRange + " and " + maxRange);
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);					
				}
			}

			// Sort By Price 1 for ascending Order and -1 for descending Order

			else if (sortType != 0) {
				if (sortType == 1 || sortType == -1) {
					response.setStatus(200);
					response.setData(productRepo.sortByPrice(sortType));
					tr = ResponseEntity.ok(response);
				} else {
					response.setStatus(400);
					response.setMessage("sortType Must be 1 or -1");
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			}
			// Filter Product by Price and Category and sorting
			else if (productName != null && !productName.isEmpty()) {
				List<Product> list = productRepo.findByProductName(productName);
				if (list.size() > 0) {
					response.setStatus(200);
					response.setData(list);
					tr = ResponseEntity.ok().body(response);
				} else {
					response.setStatus(400);
					response.setMessage(productName + " Product Not Found");
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			}
			// ViewAllProducts
			else {
				List<Product> list = productRepo.findAll();
				if (list.size() > 0) {
					response.setStatus(200);
					response.setData(list);
					tr = ResponseEntity.ok().body(response);
				} else {
					response.setStatus(400);
					response.setMessage(" No Products");
					tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			}

		} catch (Exception e) {
			throw new CustomeException("Exception occurred while getting products", e);
		}
		return tr;
	}




	// Add Products
	public ResponseEntity<?> addProduct(@Valid Product product) throws CustomeException {
		ResponseEntity<?> tr=null;
		try {
			Product	pro = productRepo.findProductByIsbn(product.getIsbnNo());
			BaseResponse<String> response = new BaseResponse<>();
			if (pro!=null) {
				response.setStatus(200);
				response.setMessage(product.getName()+" Book is Already Exist");
				tr= ResponseEntity.status(HttpStatus.BAD_REQUEST).body( response);
			}
			else {
				product.setId((int) sequenceGeneratorService.generateSequence(Product.SEQUENCE_NAME));
				productRepo.save(product);
				response.setStatus(200);
				response.setData(product.getName() + " : Book Successfully Added");
				tr= ResponseEntity.status(HttpStatus.CREATED).body(response);				
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred  in ProductService  while Adding Products", e);
		}
		return tr;
	}

	// Edit (Update)Products
	public ResponseEntity<BaseResponse<String>> updateProduct(int id, Product product) throws CustomeException {
		ResponseEntity<BaseResponse<String>> tr=null;
		try {
			BaseResponse<String> response = new BaseResponse<>();
			if (id > 0 && product != null) {
				Product cat = productRepo.findProductsById(id);
				if (cat!=null) {
					cat.setName(product.getName());
					cat.setPrice(product.getPrice());
					cat.setPages(product.getPages());
					cat.setIsbnNo(product.getIsbnNo());
					cat.setCategory(product.getCategory());
					cat.setAuthor(product.getAuthor());
					cat.setDescription(product.getDescription());
					cat.setLanguage(product.getLanguage());
					productRepo.save(cat);
					response.setStatus(200);
					response.setData(  product.getName() + " Book  is Successfully Updated");
					tr = ResponseEntity.ok().body( response);					
				} else {
					response.setStatus(200);
					response.setMessage(id +" Product is Not Found");
					tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
				}
			} else {
				response.setMessage(id +" Product is Not Found");
				tr = ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred  in ProductService updateProduct", e);
		}
		return  tr;
	}

	// Delete Products
	public ResponseEntity<BaseResponse<String>> deleteProduct(int id) throws CustomeException {
		ResponseEntity<BaseResponse<String>> tr=null;
		try {
			BaseResponse<String> response = new BaseResponse<>();
			if(productRepo.existsById(id)) {
				productRepo.deleteById(id);
				response.setStatus(200);
				response.setData(id + " Succefully deleted");
				tr= ResponseEntity.ok().body( response);
			}
			else {
				response.setStatus(200);
				response.setMessage(id +" Product does not exist");
				tr= ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
			}
		} catch (Exception e) {
			throw new CustomeException("Exception occurred  in ProductService  showProductByCategoty", e);
		}
		return tr;
	}


	public ResponseEntity<BaseResponse<String>> deleteAllProduct() throws CustomeException {
		ResponseEntity<BaseResponse<String>> tr=null;
		try {
			productRepo.deleteAll();
			BaseResponse<String> response = new BaseResponse<>();
			response.setStatus(200);
			response.setData("All Products Deleted By Admin");
			tr= ResponseEntity.ok().body( response);
		} catch (Exception e) {
			throw new CustomeException("Exception occurred  in ProductService  deleteAllProduct", e);
		}
		return tr;
	}

}
// ShowByCategory(Aggregation)
//public List<Product> showProductByCategoty(String name) throws CustomeException {
//	try {
//		return productRepo.findProductByCategory(name);
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService  showProductByCategoty", e);
//	}
//}

// FilterProduct by Price max & min(Aggregation)
//public List<Product> filterByPrice(int minprice, int maxprice) throws CustomeException {
//	try {
//		return productRepo.filterByPrice(minprice, maxprice);
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService  FilterProduct", e);
//	}
//}
//
//public List<Product> searchByName(String name) throws CustomeException {
//	try {
//		return productRepo.findByProductName(name);
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService  searchByName", e);
//	}
//}

//public List<Product> sortByPrice(int sortType) throws CustomeException {
//	try {
//		return productRepo.sortByPrice(sortType);
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService sortByPrice", e);
//	}
//}
// View Single Products

//public List<Product> showProductById(int id) throws CustomeException {
//	try {
//		return productRepo.findProductById(id);
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService  showProductById", e);
//	}
//}
// View All Products
//public List<Product> getAllProducts() throws CustomeException {
//	try {
//		return productRepo.findAll();
//	} catch (Exception e) {
//		throw new CustomeException("Exception occurred  in ProductService  getAllProducts", e);
//	}
//}