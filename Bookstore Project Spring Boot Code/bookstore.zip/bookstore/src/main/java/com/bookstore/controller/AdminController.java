package com.bookstore.controller;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.exception.CustomeException;
import com.bookstore.model.Product;
import com.bookstore.model.User;
import com.bookstore.payload.response.BaseResponse;
import com.bookstore.service.OrderService;
import com.bookstore.service.ProductService;
import com.bookstore.service.UserService;



@RestController
@RequestMapping("/admin")
public class AdminController {

	private static Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private	ProductService productService;	

	@Autowired
	private	UserService userService;

	@Autowired
	private	OrderService orderService;


	//-----------------------Product Section----------------------------------------------------------	

	//	1.	Add Products
	@PostMapping("/product/add")
	public ResponseEntity<?> addProducts(@RequestBody @Valid Product product) 
	{	
		ResponseEntity<?> tr = null;
		try {
			tr=productService.addProduct(product);
		} catch (CustomeException e) {
			logger.error("Exception occurred in ProductService updateProduct", e);
		}
		return tr;
	}

	//	4.	Edit (Update)Products
	@PutMapping("/product/update/{id}")
	public ResponseEntity<BaseResponse<String>> updateProductById(@PathVariable("id") int id, @RequestBody @Valid Product product) 
	{		
		ResponseEntity<BaseResponse<String>> tr=null;
		try {
			tr=productService.updateProduct(id, product);
		} catch (CustomeException e) {
			logger.error("Exception occurred in ProductService updateProduct", e);
		}
	return	tr;
	}

	//	5.	Delete Products
	@DeleteMapping("/product/delete/{id}")
	public ResponseEntity<BaseResponse<String>> productDeleteById(@PathVariable("id") int id)
	{ ResponseEntity<BaseResponse<String>> tr=null;
	try {
		tr=productService.deleteProduct(id);
	} catch (CustomeException e) {
		logger.error("Exception occurred in ProductService deleteProduct", e);
	}
	return tr;
	}

	//Delete All Products
	@DeleteMapping("/product/delete/all")
	public ResponseEntity<BaseResponse<String>> productAllDelete()
	{ ResponseEntity<BaseResponse<String>> tr=null;
	try {
		tr= productService.deleteAllProduct();

	} catch (CustomeException e) {
		logger.error("Exception occurred in ProductService deleteAllProduct", e);
	}
	return tr;	
	}

	//-------------------------End Product Section--------------------------------------------------------

	//-------------------------User Section---------------------------------------------------------------
	//	6.	View  list  Users	
	@GetMapping("/dashboard/users")
	public ResponseEntity<?>  viewAllUsers() 
	{  
		ResponseEntity<?> tr=null;
		try {
			tr=  userService.viewUser();
		} catch (CustomeException e) {
			logger.error("Exception occurred in OrderService getAllOrders", e);
		}
		return tr;
	}

	// View Single User 
	@GetMapping("/dashboard/users/{username}")
	public ResponseEntity<BaseResponse<User>> viewUserByID(@PathVariable("username") String username)
	{	
		ResponseEntity<BaseResponse<User>> tr=null;
		try {
			tr= userService.viewUserByUsername(username);
		} catch (CustomeException e) {
			logger.error("Exception occurred in UserService viewUserById", e);
		}
		return tr;

	}

	//	7.	Delete Single Users 
	@DeleteMapping("/dashboard/user/delete/{username}")
	public ResponseEntity<BaseResponse<String>> deleteUser(@PathVariable("username") String username)
	{	ResponseEntity<BaseResponse<String>> tr=null;
	try {
		tr=	userService.deleteUserByUsername(username);
	} catch (CustomeException e) {
		logger.error("Exception occurred in UserService viewUserById", e);
	}
	return tr;
	}

	//Delete All user
	@DeleteMapping("/dashboard/user/delete/all")
	public ResponseEntity<?> deleteAllUsers()
	{ ResponseEntity<?> tr= null;
	try {
		tr =userService.deleteAllUser();

	} catch (CustomeException e) {
		logger.error("Exception occurred in UserService deleteAllUser", e);
	}
	return tr;	
	}
	//------------------------- End User -------------------------------------------------------------------

	//--------------------------- Start Order Section--------------------------------------------------------	
	//	8.	View All Orders
	@GetMapping("/dashbord/orders")
	public ResponseEntity<?> showAllOrder()
	{ ResponseEntity<?> tr=null;
	try {
		tr= orderService.getAllOrder();  

	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService getAllOrders", e);
	}
	return tr;
	}

	//	9.	Delete single 
	@DeleteMapping("/dashbord/orders/delete/{id}")
	public ResponseEntity<BaseResponse<String>> deleteOrdersById(@PathVariable("id") int id) 
	{ ResponseEntity<BaseResponse<String>> tr = null;
	try {
		tr=	orderService.deleteOrderById(id);
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService deleteOrderById", e);
	}
	return tr;
	}

	// 10. Delete All Orders
	@DeleteMapping("/dashbord/orders/delete/all")
	public ResponseEntity<?> deleteAllOrders() 
	{ ResponseEntity<?> tr = null;
	try {
		tr =	orderService.deleteAllOrder();
	} catch (CustomeException e) {
		logger.error("Exception occurred in OrderService deleteAllOrder", e);
	}
	return tr ;
	}

	//--------------------------- End Order Section--------------------------------------------------------
}
