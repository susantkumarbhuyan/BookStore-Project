package com.bookstore.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bookstore.exception.CustomeException;
import com.bookstore.model.Address;
import com.bookstore.payload.request.CartRequest;
import com.bookstore.payload.request.CheckoutPaymentRequest;
import com.bookstore.service.CartService;
import com.bookstore.service.CheckoutService;

@RestController

public class CartCheckoutController {
	private static Logger logger = LoggerFactory.getLogger(CartCheckoutController.class);

	@Autowired
	private CartService cartService;
	@Autowired
	private CheckoutService checkoutService;

	// 1. AddToCart
	@PostMapping("/cart/add")
	public ResponseEntity<?> addToCart(@RequestBody CartRequest cartRequest,HttpSession session)
	{ ResponseEntity<?> tr=null;
	try {
		String emailId=	(String) session.getAttribute("emailId");
		tr=cartService.addCart(cartRequest,emailId);
	} catch (CustomeException e) {
		logger.error("Exception occurred in  CartService addCart", e);
	}
	return tr;
	}

	// 2. ViewCart
	@GetMapping("/cart")
	public ResponseEntity<?> showCartItems(HttpSession session){
		ResponseEntity<?> tr=null;
		try {
			String emailId=	(String) session.getAttribute("emailId");
			tr=cartService.showCart(emailId);
		} catch (CustomeException e) {
			logger.error("Exception occurred in CartService showCart", e);
		}
		return tr;
	}

	// 3. RemoveCartItem
	@DeleteMapping("/cart/delete/{id}")
	public ResponseEntity<?> deleteCartItem(@PathVariable("id") int id) {
		ResponseEntity<?>  tr=null;
		try {
			tr=	ResponseEntity.ok(cartService.deleteCart(id));
		} catch (CustomeException e) {
			logger.error("Exception occurred in CartService deleteAllCart", e);
		}
		return tr;
	}

	// Remove All Items From Cart
	@DeleteMapping("/cart/delete/all")
	public ResponseEntity<?> deleteAllCartItem(HttpSession session) {
		ResponseEntity<?>  tr=null;
		try {
			String emailId=	(String) session.getAttribute("emailId");
			tr=ResponseEntity.ok( cartService.deleteAllCart(emailId));
		} catch (CustomeException e) {
			logger.error("Exception occurred in CartService deleteAllCart", e);
		}
		return tr;
	}

	//	5.	Edit Cart (Update Quantity BY Id)
	@PutMapping("/cart/update")
	public ResponseEntity<?> updateCartItem(@RequestBody CartRequest cartRequest) {
		ResponseEntity<?>  tr=null;
		try {
			tr=cartService.updateCart(cartRequest);
		} catch (CustomeException e) {
			logger.error("Exception occurred in CartService updateCart", e);
		}
		return tr;
	}

	// 4. Checkout
	@PostMapping("/checkout")
	public ResponseEntity<?> checkOut(@RequestBody @Valid Address address,HttpSession session) {
		ResponseEntity<?> tr=null;
		try {
			String emailId=	(String) session.getAttribute("emailId");
			tr=checkoutService.addCheckout(address,emailId);
		} catch (CustomeException e) {
			logger.error("Exception occurred in CheckoutService  addCheckout", e);
		}	
		return tr;
	}

	// 5. PaymentDone OrderAdd
	@PostMapping("/checkout/payment")
	public ResponseEntity<?> paymentDone(@RequestBody CheckoutPaymentRequest request,HttpSession session )  {
		ResponseEntity<?> tr=null;
		try {
			String emailId=	(String) session.getAttribute("emailId");
			tr=checkoutService.orderCompleted( request,emailId );
		} catch (CustomeException e) {
			logger.error("Exception occurred in CartService updateCart", e);
		}
		return tr;
	}

	@DeleteMapping("/checkout/delete/all")
	public ResponseEntity<?> deleteAll(HttpSession session )  {
		ResponseEntity<?> tr=null;
		try {
			String emailId=	(String) session.getAttribute("emailId");
			tr=	checkoutService.deleteAllCheckout(emailId);			
		} catch (CustomeException e) {
			logger.error("Exception occurred in CheckOutService deleteAllCheckout", e);
		}
		return tr;
	}

	@GetMapping("/checkout/show")
	public ResponseEntity<?> showCheckout()  {
		ResponseEntity<?> tr=null;
		try {
			tr = checkoutService.showCheckout();			
		} catch (CustomeException e) {
			logger.error("Exception occurred in CheckOutService ShowCheckout", e);
		}
		return tr;
	}

}
